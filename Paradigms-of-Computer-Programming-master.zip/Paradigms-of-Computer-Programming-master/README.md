##Paradigms of Computer Programming
------
Quizzes and homeworks for edX course **Paradigms of Computer Programming** 

